ID:{{$livro->id_livro}}<br>
Título:{{$livro->titulo}}<br>
Idioma:{{$livro->idioma}}

@if(isset($livro->genero->designacao))
{{$livro->genero->designacao}}
@endif